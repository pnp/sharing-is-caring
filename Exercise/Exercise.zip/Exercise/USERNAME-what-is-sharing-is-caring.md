---
title: What is Sharing is Caring
ms.date: 3/13/2020
author: JoanneHendrickson
ms.reviewer:  jhendr
localization_priority: 
description: This is a page that is modified during the Sharing is Caring workshop
ms.collection:  SPCommunity
---

[!INCLUDE [content-disclaimer](includes/content-disclaimer.md)]

# What is "Sharing is Caring"

The "Sharing Is Caring" repository is targeted for learning the basics around making changes in GitHub, submitting pull requests to the PnP repositories and coming soon...PnP Contribution Rewards.

---

**Principal author**: [Your Name Here](http://www.linkedin.com/in/YourProfileLink)

---

![Parker](URL)
